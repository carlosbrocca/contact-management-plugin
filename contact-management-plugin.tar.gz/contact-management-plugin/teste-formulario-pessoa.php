<?php
/*
 * Template Name: Teste Formulário Pessoa
 */
get_header();

?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>

            <div class="entry-content">
                <?php
                // Inclua aqui o formulário
                exibir_formulario_pessoa();
                ?>
            </div>
        </article>

    </main>
</div>

<?php
get_footer();
