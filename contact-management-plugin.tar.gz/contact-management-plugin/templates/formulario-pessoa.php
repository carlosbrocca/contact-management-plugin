<!-- templates/formulario-pessoa.php -->
<form method="post">
    <label>
        Nome:
        <input type="text" name="nome" value="<?php echo esc_attr($nome); ?>" required>
    </label>

    <label>
        Email:
        <input type="email" name="email" value="<?php echo esc_attr($email); ?>" required>
    </label>

    <input type="hidden" name="pessoa_id" value="<?php echo esc_attr($pessoa_id); ?>">
    <input type="submit" name="submit_pessoa" value="Salvar Pessoa">
</form>
