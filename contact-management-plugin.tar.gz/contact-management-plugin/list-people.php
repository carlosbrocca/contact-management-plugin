<h2>Lista de Pessoas</h2>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Telefone</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php
// Adicione o código para listar as pessoas
global $wpdb;

$pessoas = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}pessoas");

foreach ($pessoas as $pessoa) :
?>
    <tr>
        <td><?php echo esc_html($pessoa->id); ?></td>
        <td><?php echo esc_html($pessoa->nome); ?></td>
        <td><?php echo esc_html($pessoa->email); ?></td>
        <td><?php echo esc_html($pessoa->telefone); ?></td>
        <td>
            <a href="?page=contact_management_plugin&action=edit&id=<?php echo esc_attr($pessoa->id); ?>">Editar</a>
            <a href="?page=contact_management_plugin&action=delete&id=<?php echo esc_attr($pessoa->id); ?>">Excluir</a>
        </td>
    </tr>
<?php endforeach; ?>

    </tbody>
</table>
