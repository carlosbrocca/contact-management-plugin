<h2>Adicionar Pessoa</h2>
<form method="post" action="">
    <label for="nome">Nome:</label>
    <input type="text" name="nome" required>

    <label for="email">Email:</label>
    <input type="email" name="email" required>

    <label for="telefone">Telefone:</label>
    <input type="text" name="telefone" required>

    <input type="submit" name="submit" value="Adicionar Pessoa">
</form>
