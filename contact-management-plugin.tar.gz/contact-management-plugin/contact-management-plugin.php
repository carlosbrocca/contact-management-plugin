<?php
/*
Plugin Name: Contact Management Plugin
Description: Contact management in WordPress.
Version: 1.0
Author: @carlosbrocca
*/



// funçao para aparecer no menu wordpress
function contact_management_plugin_menu() {
    add_menu_page(
        'Contact Management Plugin',
        'Lista de pessoas',
        'manage_options',
        'contact_management_plugin',
        'contact_management_plugin_page',
        'dashicons-businessman', // Ícone do menu (altere conforme desejado)
        20 // Posição do menu
    );

// Funçao de um submenu para "Incluir Pessoa"
    add_submenu_page(
        'contact_management_plugin',
        'Incluir Pessoa',
        'Incluir Pessoa',
        'manage_options',
        'contact_management_plugin_add',
        'contact_management_plugin_add_page'
    );
}

add_action('admin_menu', 'contact_management_plugin_menu');

// Função para a página de "Incluir Pessoa"
function contact_management_plugin_add_page() {
    ?>
    <div class="wrap">
        <h1>Incluir Pessoa</h1>

        <form method="post" action="">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" required>

            <label for="email">Email:</label>
            <input type="email" name="email[]" required>

            <label for="telefone">Telefone:</label>
            <input type="text" name="telefone[]" required>

            <button type="button" id="add-email">Adicionar Email</button>
            <button type="button" id="add-telefone">Adicionar Telefone</button>

            <input type="submit" name="submit" value="Incluir Pessoa">
        </form>
    </div>

    <script>
    
        // Adiciona campos de email e telefone
        document.addEventListener('DOMContentLoaded', function () {
            const addEmailButton = document.getElementById('add-email');
            const addTelefoneButton = document.getElementById('add-telefone');

            addEmailButton.addEventListener('click', function () {
                const input = document.createElement('input');
                input.type = 'email';
                input.name = 'email[]';
                input.required = true;

                document.querySelector('form').insertBefore(input, this);
            });

            addTelefoneButton.addEventListener('click', function () {
                const input = document.createElement('input');
                input.type = 'text';
                input.name = 'telefone[]';
                input.required = true;

                document.querySelector('form').insertBefore(input, this);
            });

            // Adiciona um evento de submit para redirecionamento após a inclusão
            document.querySelector('form').addEventListener('submit', function () {
                alert('Pessoa incluída com sucesso!'); // Somente um alerta
                location.reload(); // Recarregar a pagina
            });
        });
    </script>
    <?php
}


// Esta para incluir a pessoa no banco de dados
function processar_formulario_inclusao_pessoa() {
    global $wpdb;

    if (isset($_POST['submit'])) {
        $nome = sanitize_text_field($_POST['nome']);
        $emails = array_map('sanitize_email', $_POST['email']);
        $telefones = array_map('sanitize_text_field', $_POST['telefone']);

        // Insere a pessoa no banco de dados
        $wpdb->insert(
            $wpdb->prefix . 'pessoas',
            array('nome' => $nome),
            array('%s')
        );

        $pessoa_id = $wpdb->insert_id;

        // Insere os emails no banco de dados
        foreach ($emails as $email) {
            $wpdb->insert(
                $wpdb->prefix . 'contatos',
                array('pessoa_id' => $pessoa_id, 'tipo' => 'email', 'valor' => $email),
                array('%d', '%s', '%s')
            );
        }

        // Insere os telefones no banco de dados
        foreach ($telefones as $telefone) {
            $wpdb->insert(
                $wpdb->prefix . 'contatos',
                array('pessoa_id' => $pessoa_id, 'tipo' => 'telefone', 'valor' => $telefone),
                array('%d', '%s', '%s')
            );
        }

        // Redireciona para a página de listagem de pessoas após a inclusão
        wp_redirect(admin_url('admin.php?page=contact_management_plugin'));
        exit;
    }
}

// Adiciona a ação para processar o formulário de inclusão
add_action('admin_init', 'processar_formulario_inclusao_pessoa');


// Função para a exclusão de pessoas
function contact_management_plugin_delete_person() {
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['person_id'])) {
        $person_id = absint($_GET['person_id']);

        // Certifique-se de validar a autorização para excluir antes de prosseguir
        if (current_user_can('manage_options')) {
            global $wpdb;

            $pessoas_table = $wpdb->prefix . 'pessoas';

            $contatos_table = $wpdb->prefix . 'contatos';

            // Exclua a pessoa
            $wpdb->delete($pessoas_table, array('id' => $person_id), array('%d'));

            // Exclua os contatos associados a essa pessoa
            $wpdb->delete($contatos_table, array('pessoa_id' => $person_id), array('%d'));

            // Redirecione para a página de lista após a exclusão
            wp_redirect(admin_url('admin.php?page=contact_management_plugin'));
            exit;
        }
    }
}

add_action('admin_init', 'contact_management_plugin_delete_person');





// Função para a página de "Listar Pessoas"
function contact_management_plugin_page() {
    ?>
    <div class="wrap">
        <h1>Lista de pessoas</h1>

        <?php
        // Verifica se uma ação específica foi solicitada
        $action = isset($_GET['action']) ? $_GET['action'] : '';

        switch ($action) {
            case 'add':
                // Se a ação for adicionar, inclua o formulário de adição
                include_once 'add-person-form.php';
                break;

            case 'edit':
                // Se a ação for editar, inclua o formulário de edição
                include_once 'edit-person-form.php';
                break;

            default:
                // Se nenhuma ação específica, mostre a lista de pessoas
                include_once 'list-people.php';
        }
        ?>
    </div>
    <?php
}



add_action('admin_menu', 'contact_management_plugin_menu');

	//Adicionando banco de dados de lista de pessoas
	function criar_tabela_pessoas() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'pessoas';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			nome varchar(100) NOT NULL,
			email varchar(100) NOT NULL,
			telefone varchar(20) NOT NULL,
			PRIMARY KEY  (id)
		) $charset_collate;";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}


	// Adicionando uma página de lista de pessoas
	function lista_pessoas_shortcode() {
		global $wpdb;

		$pessoas = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}pessoas");

		ob_start(); // Inicia o buffer de saída
		?>
		<p>Lista de Pessoas:</p>
		<ul>
			<?php foreach ($pessoas as $pessoa) : ?>
				<li><?php echo esc_html($pessoa->nome); ?> - <?php echo esc_html($pessoa->email); ?> - <?php echo esc_html($pessoa->telefone); ?></li>
			<?php endforeach; ?>
		</ul>
		<?php
		return ob_get_clean(); // Retorna e limpa o buffer de saída
	}

	add_shortcode('lista_pessoas', 'lista_pessoas_shortcode');
	


	// Adicionando uma página de adição/edição de pessoa
	function formulario_pessoa_shortcode() {
		ob_start(); // Inicia o buffer de saída

		// Processar o formulário
		if (isset($_POST['submit_pessoa'])) {
			$nome = sanitize_text_field($_POST['nome']);
			$email = sanitize_email($_POST['email']);
			$telefone = sanitize_text_field($_POST['telefone']);

			// salvar dados no banco de dados
			global $wpdb;
			$wpdb->insert(
				"{$wpdb->prefix}pessoas",
				array(
					'nome' => $nome,
					'email' => $email,
					'telefone' => $telefone,
				)
			);

			echo "Dados recebidos: Nome - $nome, Email - $email, Telefone - $telefone";
		}

		?>
		<form method="post">
			<label for="nome">Nome:</label>
			<input type="text" name="nome" id="nome" required>

			<label for="email">Email:</label>
			<input type="email" name="email" id="email" required>

			<label for="telefone">Telefone:</label>
			<input type="tel" name="telefone" id="telefone" required>

			<input type="submit" name="submit_pessoa" value="Salvar Pessoa">
		</form>
		<?php
		return ob_get_clean(); // Retorna e limpa o buffer de saída
	}

	add_shortcode('formulario_pessoa', 'formulario_pessoa_shortcode');
	
	
	
	// Adicionando uma página de detalhes da pessoa
function detalhes_pessoa_shortcode($atts) {
    global $wpdb;

    $atts = shortcode_atts(
        array(
            'id' => 0,
        ),
        $atts,
        'detalhes_pessoa'
    );

    $pessoa = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pessoas WHERE id = %d", $atts['id']));

    ob_start(); // Inicia o buffer de saída
    ?>
    <h2>Detalhes da Pessoa</h2>
    <?php if ($pessoa) : ?>
        <p>ID: <?php echo esc_html($pessoa->id); ?></p>
        <p>Nome: <?php echo esc_html($pessoa->nome); ?></p>
        <p>Email: <?php echo esc_html($pessoa->email); ?></p>
        <p>Telefone: <?php echo esc_html($pessoa->telefone); ?></p>
    <?php else : ?>
        <p>Pessoa não encontrada.</p>
    <?php endif; ?>
    <?php
    return ob_get_clean(); // Retorna e limpa o buffer de saída
}

add_shortcode('detalhes_pessoa', 'detalhes_pessoa_shortcode');


// Adicionando uma página de edição de pessoa
function editar_pessoa_shortcode($atts) {
    global $wpdb;

    $atts = shortcode_atts(
        array(
            'id' => 0,
        ),
        $atts,
        'editar_pessoa'
    );

    $pessoa = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pessoas WHERE id = %d", $atts['id']));

    ob_start(); // Inicia o buffer de saída
    ?>
    <h2>Editar Pessoa</h2>
    <?php if ($pessoa) : ?>
        <form method="post" action="">
            <input type="hidden" name="id" value="<?php echo esc_attr($pessoa->id); ?>">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" value="<?php echo esc_attr($pessoa->nome); ?>" required>
            <br>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" value="<?php echo esc_attr($pessoa->email); ?>" required>
            <br>
            <label for="telefone">Telefone:</label>
            <input type="tel" name="telefone" id="telefone" value="<?php echo esc_attr($pessoa->telefone); ?>" required>
            <br>
            <input type="submit" value="Atualizar Pessoa">
        </form>
    <?php else : ?>
        <p>Pessoa não encontrada.</p>
    <?php endif; ?>
    <?php
    return ob_get_clean(); // Retorna e limpa o buffer de saída
}

add_shortcode('editar_pessoa', 'editar_pessoa_shortcode');



// Função para processar o formulário de adição de pessoa
function processar_formulario_adicao_pessoa() {
    global $wpdb;

    if (isset($_POST['submit'])) {
        $nome = sanitize_text_field($_POST['nome']);
        $email = sanitize_email($_POST['email']);
        $telefone = sanitize_text_field($_POST['telefone']);

        // Verifica se o email já existe no banco de dados
        $existe_email = $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}pessoas WHERE email = %s", $email)
        );

        if ($existe_email > 0) {
            // Email já existe, trate conforme necessário (ex: exiba uma mensagem de erro)
            echo '<p>Email já cadastrado. Escolha outro email.</p>';
        } else {
            // Adiciona a pessoa no banco de dados
            $wpdb->insert(
                $wpdb->prefix . 'pessoas',
                array(
                    'nome' => $nome,
                    'email' => $email,
                    'telefone' => $telefone,
                ),
                array('%s', '%s', '%s')
            );

            // Redireciona para a página de listagem de pessoas após a adição
            wp_redirect(admin_url('admin.php?page=contact_management_plugin'));
            exit;
        }
    }
}

// Adiciona a ação para processar o formulário
add_action('admin_init', 'processar_formulario_adicao_pessoa');

// Ativar plugin
	function ativar_plugin() {
		criar_tabela_pessoas();
	}

	register_activation_hook(__FILE__, 'ativar_plugin');
