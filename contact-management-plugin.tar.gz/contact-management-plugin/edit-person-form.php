<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Processar o formulário quando for enviado
    if (isset($_POST['update_person'])) {
        $nome = sanitize_text_field($_POST["nome"]);
        $email = sanitize_email($_POST["email"]);
        $telefone = sanitize_text_field($_POST["telefone"]);
        $person_id = intval($_POST["person_id"]);

        // Verificar se os campos obrigatórios não estão vazios
        if (empty($nome) || empty($email) || empty($telefone)) {
            $error_message = "Todos os campos são obrigatórios.";
        } else {
            // Atualizar os dados da pessoa no banco de dados
            global $wpdb;
            $wpdb->update(
                "{$wpdb->prefix}pessoas",
                array('nome' => $nome, 'email' => $email, 'telefone' => $telefone),
                array('id' => $person_id),
                array('%s', '%s', '%s'),
                array('%d')
            );

            // Redirecionar para a lista de pessoas após a atualização
            wp_redirect(admin_url('admin.php?page=contact_management_plugin'));
            exit();
        }
    }
}

// Obter ID da pessoa da consulta URL
$person_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Obter dados da pessoa do banco de dados
global $wpdb;
$person = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pessoas WHERE id = %d", $person_id));

// Verificar se a pessoa existe
if (!$person) {
    echo 'Pessoa não encontrada.';
    exit;
}
?>

<!-- Adicione este código no restante do arquivo edit-person-form.php -->

<div class="wrap">
    <h2>Editar Pessoa</h2>

    <?php if (isset($error_message)) : ?>
        <div class="notice notice-error">
            <p><?php echo esc_html($error_message); ?></p>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <input type="hidden" name="person_id" value="<?php echo esc_attr($person->id); ?>">

        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="nome">Nome</label></th>
                    <td><input type="text" name="nome" id="nome" value="<?php echo esc_attr($person->nome); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="email">Email</label></th>
                    <td><input type="email" name="email" id="email" value="<?php echo esc_attr($person->email); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="telefone">Telefone</label></th>
                    <td><input type="tel" name="telefone" id="telefone" value="<?php echo esc_attr($person->telefone); ?>" class="regular-text" required></td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="update_person" id="update_person" class="button button-primary" value="Atualizar Pessoa">
            <a href="<?php echo admin_url('admin.php?page=contact_management_plugin'); ?>" class="button">Cancelar</a>
        </p>
    </form>
</div>
