<?php
// Adicione este código no início do arquivo delete-person.php

// Obter ID da pessoa da consulta URL
$person_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Verificar se o formulário foi enviado e o nonce é válido
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_person']) && check_admin_referer('delete_person_nonce', 'delete_person_nonce')) {
    // Excluir a pessoa do banco de dados
    global $wpdb;
    $wpdb->delete(
        "{$wpdb->prefix}pessoas",
        array('id' => $person_id),
        array('%d')
    );

    // Redirecionar para a lista de pessoas após a exclusão
    wp_redirect(admin_url('admin.php?page=contact_management_plugin'));
    exit();
}

// Obter dados da pessoa do banco de dados
global $wpdb;
$person = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pessoas WHERE id = %d", $person_id));

// Verificar se a pessoa existe
if (!$person) {
    echo 'Pessoa não encontrada.';
    exit;
}
?>

<!-- Adicione este código no restante do arquivo delete-person.php -->

<div class="wrap">
    <h2>Excluir Pessoa</h2>

    <p>Tem certeza de que deseja excluir a pessoa <strong><?php echo esc_html($person->nome); ?></strong>?</p>

    <form method="post" action="">
        <?php wp_nonce_field('delete_person_nonce', 'delete_person_nonce'); ?>
        <input type="hidden" name="person_id" value="<?php echo esc_attr($person->id); ?>">

        <p class="submit">
            <input type="submit" name="delete_person" id="delete_person" class="button button-primary" value="Sim, Excluir Pessoa">
            <a href="<?php echo admin_url('admin.php?page=contact_management_plugin'); ?>" class="button">Cancelar</a>
        </p>
    </form>
</div>
